<?php $__env->startSection('content'); ?>


    <div class="contact_form">
        <div class="container">
            <div class="row">
               <div class="col-8 card">
                 <table class="table table-response">
                   <thead>
                     <tr>
                       <th scope="col">PaymentType</th>
                       <th scope="col">Return</th>
                       <th scope="col">Amount</th>
                       <th scope="col">Date</th>
                        <th scope="col">Status </th>
                        <th scope="col">Action</th>
                     </tr>
                   </thead>
                   <tbody>
                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                       <th ><?php echo e($row->payment_type); ?></th>
                       <td>
                       	     	<?php if($row->return_order == 0): ?>
		                       	 <span class="badge badge-warning">No Request</span>
		                       	<?php elseif($row->return_order == 1): ?>
		                       	<span class="badge badge-info">Pending</span>
		                       	<?php elseif($row->return_order == 2): ?> 
		                       	 <span class="badge badge-info">Success </span>
		                       	<?php endif; ?>
                       </td>
                       <td><?php echo e($row->total); ?> $</td>
                       <td><?php echo e($row->date); ?></td>
                       <td>
                       	<?php if($row->status == 0): ?>
                       	 <span class="badge badge-warning">Pending</span>
                       	<?php elseif($row->status == 1): ?>
                       	<span class="badge badge-info">Payment Accept</span>
                       	<?php elseif($row->status == 2): ?> 
                       	 <span class="badge badge-info">Progress </span>
                       	 <?php elseif($row->status == 3): ?>  
                       	 <span class="badge badge-success">Delevered </span>
                       	 <?php else: ?>
                       	 <span class="badge badge-danger">Cancel </span>
                       	 <?php endif; ?>
                       </td>
                       <td>
                       	<?php if($row->return_order == 0): ?>
                         <a href="<?php echo e(url('/request/return/'.$row->id)); ?>" class="btn btn-sm btn-danger" id="return">Return</a>
                         <?php elseif($row->return_order == 1): ?>
		                       	<span class="badge badge-info">Pending</span>
		                 <?php elseif($row->return_order == 2): ?> 
		                       	 <span class="badge badge-info">Success </span>
                         <?php endif; ?>
                       </td>
                     </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                 </table>
               </div>
               <div class="col-4">
                 <div class="card" style="width: 18rem;">
                  <img src="<?php echo e(asset('public/avatar.jpg')); ?>" class="card-img-top" style="height: 90px; width: 90px; margin-left: 34%;" >
                  <div class="card-body">
                    <h5 class="card-title text-center"><?php echo e(Auth::user()->name); ?></h5>
                  </div>
                  <ul class="list-group list-group-flush">
                    <li class="list-group-item"><a href="<?php echo e(route('password.change')); ?>"> Password Change </a></li>
                    <li class="list-group-item"><a href="<?php echo e(route('password.change')); ?>"> Edit Profile </a></li>
                    <li class="list-group-item"><a href="<?php echo e(route('success.orderlist')); ?>"> Return Order </a></li>
                  </ul>
                  <div class="card-body">
                    <a href="<?php echo e(route('user.logout')); ?>" class="btn btn-danger btn-sm btn-block">Logout</a>
                  </div>
                </div>
               </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\multiauth\resources\views/pages/returnorder.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row ">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-center"><?php echo e(__('Change Your Password')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('password.update')); ?>" aria-label="<?php echo e(__('Reset Password')); ?>">
                        <?php echo csrf_field(); ?>


                        <div class="form-group row">
                            <label for="oldpass" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Old Password')); ?></label>

                            <div class="col-md-6">
                                <input id="oldpass" type="password" class="form-control<?php echo e($errors->has('oldpass') ? ' is-invalid' : ''); ?>" name="oldpass" value="<?php echo e($oldpass ?? old('oldpass')); ?>" required autofocus>

                                <?php if($errors->has('oldpass')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('oldpass')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Password Change')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="col-4">
                 <div class="card" style="width: 18rem;">
                  <img src="<?php echo e(asset('public/avatar.jpg')); ?>" class="card-img-top" style="height: 90px; width: 90px; margin-left: 34%;" >
                  <div class="card-body">
                    <h5 class="card-title text-center"><?php echo e(Auth::user()->name); ?></h5>
                  </div>
                  <ul class="list-group list-group-flush">
                    <li class="list-group-item"><a href="<?php echo e(route('password.change')); ?>"> Password Change </a></li>
                    <li class="list-group-item">Dapibus ac facilisis in</li>
                    <li class="list-group-item">Vestibulum at eros</li>
                  </ul>
                  <div class="card-body">
                    <a href="<?php echo e(route('user.logout')); ?>" class="btn btn-danger btn-sm btn-block">Logout</a>
                  </div>
                </div>
               </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\multiauth\resources\views/auth/changepassword.blade.php ENDPATH**/ ?>
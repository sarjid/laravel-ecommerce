<?php $__env->startSection('admin_content'); ?>
    <div class="sl-mainpanel">
      <div class="sl-pagebody">
        <div class="sl-page-title">
          <h5> Orders Details</h5>
        </div><!-- sl-page-title -->

        <div class="card pd-20 pd-sm-40">
          <h6 class="card-body-title">Orders List </h6>
          <br>
          <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
              <thead>
                <tr>
                  <th class="wd-15p">Payment Type</th>
                  <th class="wd-15p">Transection ID</th>
                  <th class="wd-15p">Subtotal</th>
                  <th class="wd-20p">Shipping</th>
                  <th class="wd-20p">Total</th>
                   <th class="wd-20p">Date</th>
                   <th class="wd-20p">Return</th>
                   <th class="wd-20p">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($row->payment_type); ?></td>
                  <td><?php echo e($row->blnc_transection); ?></td>
                  <td><?php echo e($row->subtotal); ?> $</td>
                  <td><?php echo e($row->shipping); ?> $</td>
                  <td><?php echo e($row->total); ?> $</td>
                  <td><?php echo e($row->date); ?> </td>
                  <td>
                    <?php if($row->return_order == 1): ?>
                     <span class="badge badge-warning">Pending</span>
                    <?php elseif($row->status == 2): ?>
                    <span class="badge badge-success">Success</span>
                     <?php endif; ?>
              
                  <td>

                  <span class="badge badge-success">Done</span>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div><!-- table-wrapper -->
        </div><!-- card -->
      </div><!-- sl-pagebody -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\multiauth\resources\views/admin/return/all.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

    <div class="contact_form">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 "  style="border: 1px solid grey; padding: 20px;">
                    <div class="contact_form_container">
                        <div class="contact_form_title text-center">Your Order Status</div> <br>

					      <div class="progress">

					      	<?php if($track->status == 0 ): ?>
 										  <div class="progress-bar bg-danger" role="progressbar" style="width: 15%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div><br>
 									
					      	<?php elseif($track->status == 1): ?>
					      				  <div class="progress-bar bg-danger" role="progressbar" style="width: 15%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>

					      				   <div class="progress-bar bg-primary" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>

					      				 
					      	<?php elseif($track->status == 2): ?>
					      	        <div class="progress-bar bg-danger" role="progressbar" style="width: 15%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>

					      		   <div class="progress-bar bg-primary" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>

					      		   <div class="progress-bar bg-info" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
					      		    
					      	<?php elseif($track->status == 3): ?>
                                     <div class="progress-bar bg-danger" role="progressbar" style="width: 15%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>


							       <div class="progress-bar bg-primary" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>


							       <div class="progress-bar bg-info" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>

							        <div class="progress-bar bg-success" role="progressbar" style="width: 35%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
					      	<?php else: ?>
					      	    <div class="progress-bar bg-danger" role="progressbar" style="width: 100" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div><br>
					      	<?php endif; ?>
					     </div>
					 </div>

				
					     <?php if($track->status == 0): ?>
					     <h4>Note: <b>Payment Accept Under Processing<b>    </h4>
					     <?php elseif($track->status == 1): ?>
					      <h4>Note: <b>Payment Accept Under Processing<b>    </h4>
					     <?php elseif($track->status == 2): ?>
					      <h4>Note: <b>Packing Done Handover Progress<b>    </h4>
					     <?php elseif($track->status == 3): ?>
					      <h4>Note: <b>Successfully Delevered Your Order<b>    </h4>
					     	<?php else: ?>
					     <h4>Note: <b>Order Cancel<b>    </h4>
					      	<?php endif; ?>
					     
					 </div>
					</div>

					  <div class="col-lg-6"  style="border: 1px solid grey; padding: 20px;">
		                    <div class="contact_form_container">
		                        <div class="contact_form_title text-center">Your Order Details</div> <br>

							      <div class="jumbotron">
									 <ul>
									 	<li>Payment Type:  <?php echo e($track->payment_type); ?></li>
									 	<li>Transection ID:  <?php echo e($track->payment_id); ?></li>
									 	<li>Balance  ID:  <?php echo e($track->blnc_transection); ?></li>
									    <li>Subtotal: <?php echo e($track->subtotal); ?> $</li>
									 	<li>Shipping: <?php echo e($track->shipping); ?> $</li>
									 	<li>Total: <?php echo e($track->total); ?> $</li>
									 	<li>Month: <?php echo e($track->month); ?></li>
									 	<li>Date: <?php echo e($track->date); ?></li>
									 </ul>
							     </div>
							 </div>
					</div>


				</div>
			</div>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\multiauth\resources\views/pages/track.blade.php ENDPATH**/ ?>